#!/bin/bash
set -e

clear
echo "============================================================"
echo "  [::] NOCTURNAL PLAYER — macOS INSTALLER (ARM64 & INTEL)"
echo "============================================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD_APP_DIR="$SCRIPT_DIR/app"
if [ ! -d "$PAYLOAD_APP_DIR" ]; then
  echo "Error: Could not find app/ payload directory next to this installer."
  read -n 1 -s -r -p "Press any key to exit..."
  exit 1
fi

# Determine target Applications folder (/Applications if writable, otherwise ~/Applications)
TARGET_APPS_DIR="/Applications"
if [ ! -w "/Applications" ]; then
  TARGET_APPS_DIR="$HOME/Applications"
  mkdir -p "$TARGET_APPS_DIR"
fi
APP_BUNDLE="$TARGET_APPS_DIR/Nocturnal player.app"

# Detect macOS CPU architecture (Apple Silicon arm64 vs Intel x64)
ARCH="$(uname -m)"
if [ "$ARCH" = "arm64" ]; then
  ELECTRON_ARCH="arm64"
  FFMPEG_ARCH="arm64"
  echo "[1/5] Detected Apple Silicon Mac (arm64)"
else
  ELECTRON_ARCH="x64"
  FFMPEG_ARCH="x64"
  echo "[1/5] Detected Intel Mac (x64)"
fi

ELECTRON_VERSION="v33.4.0"
ELECTRON_ZIP_URL="https://github.com/electron/electron/releases/download/${ELECTRON_VERSION}/electron-${ELECTRON_VERSION}-darwin-${ELECTRON_ARCH}.zip"
FFMPEG_URL="https://github.com/eugeneware/ffmpeg-static/releases/download/b5.0.1/darwin-${FFMPEG_ARCH}"

WORK_DIR="$(mktemp -d)"
cleanup() {
  rm -rf "$WORK_DIR"
}
trap cleanup EXIT

echo "[2/5] Downloading native macOS Electron runtime (${ELECTRON_VERSION} darwin-${ELECTRON_ARCH})..."
curl -L --progress-bar "$ELECTRON_ZIP_URL" -o "$WORK_DIR/electron.zip"

echo "[3/5] Extracting application bundle..."
unzip -q "$WORK_DIR/electron.zip" -d "$WORK_DIR/extracted"

# Close running Nocturnal player if open
pkill -f "Nocturnal player" 2>/dev/null || true
rm -rf "$APP_BUNDLE"
mv "$WORK_DIR/extracted/Electron.app" "$APP_BUNDLE"

# Copy Nocturnal player app source & assets into Contents/Resources/app
RESOURCES_APP="$APP_BUNDLE/Contents/Resources/app"
rm -rf "$APP_BUNDLE/Contents/Resources/default_app.asar"
mkdir -p "$RESOURCES_APP"
cp -R "$PAYLOAD_APP_DIR/"* "$RESOURCES_APP/"

# Download native macOS ffmpeg binary for YT Music audio conversion
echo "[4/5] Installing macOS ffmpeg binary for YT Music conversion..."
FFMPEG_DIR="$RESOURCES_APP/node_modules/ffmpeg-static"
mkdir -p "$FFMPEG_DIR"
if curl -L -s --fail "$FFMPEG_URL" -o "$FFMPEG_DIR/ffmpeg"; then
  chmod +x "$FFMPEG_DIR/ffmpeg"
  cat > "$FFMPEG_DIR/index.js" << 'EOF'
const path = require("path");
module.exports = path.join(__dirname, "ffmpeg");
EOF
  cat > "$FFMPEG_DIR/package.json" << 'EOF'
{"name":"ffmpeg-static","version":"5.2.0","main":"index.js"}
EOF
fi

# Build macOS .icns icon from assets/180px-soundtrack_(nocturnal_style).png using built-in sips & iconutil
ICON_SRC="$RESOURCES_APP/assets/180px-soundtrack_(nocturnal_style).png"
if [ -f "$ICON_SRC" ] && command -v sips >/dev/null 2>&1 && command -v iconutil >/dev/null 2>&1; then
  ICONSET="$WORK_DIR/Nocturnal.iconset"
  mkdir -p "$ICONSET"
  sips -z 16 16     "$ICON_SRC" --out "$ICONSET/icon_16x16.png" >/dev/null 2>&1 || true
  sips -z 32 32     "$ICON_SRC" --out "$ICONSET/icon_16x16@2x.png" >/dev/null 2>&1 || true
  sips -z 32 32     "$ICON_SRC" --out "$ICONSET/icon_32x32.png" >/dev/null 2>&1 || true
  sips -z 64 64     "$ICON_SRC" --out "$ICONSET/icon_32x32@2x.png" >/dev/null 2>&1 || true
  sips -z 128 128   "$ICON_SRC" --out "$ICONSET/icon_128x128.png" >/dev/null 2>&1 || true
  sips -z 256 256   "$ICON_SRC" --out "$ICONSET/icon_128x128@2x.png" >/dev/null 2>&1 || true
  sips -z 256 256   "$ICON_SRC" --out "$ICONSET/icon_256x256.png" >/dev/null 2>&1 || true
  sips -z 512 512   "$ICON_SRC" --out "$ICONSET/icon_256x256@2x.png" >/dev/null 2>&1 || true
  iconutil -c icns "$ICONSET" -o "$APP_BUNDLE/Contents/Resources/electron.icns" >/dev/null 2>&1 || true
fi

# Update Info.plist display name to Nocturnal player
PLIST="$APP_BUNDLE/Contents/Info.plist"
if [ -f "$PLIST" ]; then
  /usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName Nocturnal player" "$PLIST" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Set :CFBundleName Nocturnal player" "$PLIST" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier com.nocturnal.player" "$PLIST" 2>/dev/null || true
fi

# Clear macOS Gatekeeper quarantine attributes so the app opens without any warning
echo "[5/5] Finalizing permissions & Desktop shortcut..."
xattr -cr "$APP_BUNDLE" 2>/dev/null || true
ln -sf "$APP_BUNDLE" "$HOME/Desktop/Nocturnal player.app" 2>/dev/null || true

echo ""
echo "============================================================"
echo "  SUCCESS! Installed to: $APP_BUNDLE"
echo "  Launching Nocturnal player..."
echo "============================================================"
open "$APP_BUNDLE"
exit 0

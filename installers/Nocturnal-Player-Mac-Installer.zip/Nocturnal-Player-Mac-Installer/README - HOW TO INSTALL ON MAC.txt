============================================================
  [::] NOCTURNAL PLAYER — macOS INSTALLER INSTRUCTIONS
============================================================

HOW TO INSTALL ON MAC (Apple Silicon M1/M2/M3/M4 or Intel):

1. Unzip "Nocturnal-Player-Mac-Installer.zip".
2. Right-click (or Control+Click) on "Install Nocturnal player.command"
   and click "Open" (then click "Open" in the prompt).

   (Alternatively, open Terminal, drag "Install Nocturnal player.command"
   into the Terminal window, and press Enter.)

3. The installer will automatically:
   - Detect whether your Mac is Apple Silicon (arm64) or Intel (x64)
   - Build "Nocturnal player.app" inside /Applications
   - Place a shortcut on your Desktop
   - Launch Nocturnal player automatically!

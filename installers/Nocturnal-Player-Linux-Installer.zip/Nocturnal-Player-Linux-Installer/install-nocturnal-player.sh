#!/usr/bin/env bash
set -e

clear || true
echo "============================================================"
echo "  [::] NOCTURNAL PLAYER — LINUX INSTALLER (x64 & ARM64)"
echo "============================================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD_APP_DIR="$SCRIPT_DIR/app"
if [ ! -d "$PAYLOAD_APP_DIR" ]; then
  echo "Error: Could not find app/ payload directory next to this installer."
  exit 1
fi

INSTALL_DIR="$HOME/.local/opt/nocturnal-player"
BIN_DIR="$HOME/.local/bin"
APPS_DIR="$HOME/.local/share/applications"

# Detect Linux CPU architecture (x86_64 vs aarch64/arm64)
ARCH="$(uname -m)"
if [ "$ARCH" = "aarch64" ] || [ "$ARCH" = "arm64" ]; then
  ELECTRON_ARCH="arm64"
  FFMPEG_ARCH="arm64"
  echo "[1/5] Detected ARM64 Linux ($ARCH)"
else
  ELECTRON_ARCH="x64"
  FFMPEG_ARCH="x64"
  echo "[1/5] Detected x86_64 Linux ($ARCH)"
fi

ELECTRON_VERSION="v33.4.0"
ELECTRON_ZIP_URL="https://github.com/electron/electron/releases/download/${ELECTRON_VERSION}/electron-${ELECTRON_VERSION}-linux-${ELECTRON_ARCH}.zip"
FFMPEG_URL="https://github.com/eugeneware/ffmpeg-static/releases/download/b5.0.1/linux-${FFMPEG_ARCH}"

WORK_DIR="$(mktemp -d)"
cleanup() {
  rm -rf "$WORK_DIR"
}
trap cleanup EXIT

echo "[2/5] Downloading native Linux Electron runtime (${ELECTRON_VERSION} linux-${ELECTRON_ARCH})..."
if command -v curl >/dev/null 2>&1; then
  curl -L --progress-bar "$ELECTRON_ZIP_URL" -o "$WORK_DIR/electron.zip"
elif command -v wget >/dev/null 2>&1; then
  wget -q --show-progress "$ELECTRON_ZIP_URL" -O "$WORK_DIR/electron.zip"
else
  echo "Error: Neither curl nor wget is installed. Please install curl or wget and try again."
  exit 1
fi

echo "[3/5] Extracting application bundle to $INSTALL_DIR..."
pkill -f "nocturnal-player" 2>/dev/null || true
rm -rf "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
unzip -q "$WORK_DIR/electron.zip" -d "$INSTALL_DIR"

# Rename electron binary -> nocturnal-player
if [ -f "$INSTALL_DIR/electron" ]; then
  mv "$INSTALL_DIR/electron" "$INSTALL_DIR/nocturnal-player"
  chmod +x "$INSTALL_DIR/nocturnal-player"
fi

# Configure chrome-sandbox or wrapper flags so it runs out of the box on Ubuntu 24.04+ / Arch / Fedora / Hyprland
rm -rf "$INSTALL_DIR/resources/default_app.asar"
RESOURCES_APP="$INSTALL_DIR/resources/app"
mkdir -p "$RESOURCES_APP"
cp -R "$PAYLOAD_APP_DIR/"* "$RESOURCES_APP/"

# Download native Linux ffmpeg binary for YT Music audio conversion
echo "[4/5] Installing Linux ffmpeg binary for YT Music conversion..."
FFMPEG_DIR="$RESOURCES_APP/node_modules/ffmpeg-static"
mkdir -p "$FFMPEG_DIR"
if command -v curl >/dev/null 2>&1; then
  curl -L -s --fail "$FFMPEG_URL" -o "$FFMPEG_DIR/ffmpeg" || true
elif command -v wget >/dev/null 2>&1; then
  wget -q "$FFMPEG_URL" -O "$FFMPEG_DIR/ffmpeg" || true
fi
if [ -f "$FFMPEG_DIR/ffmpeg" ]; then
  chmod +x "$FFMPEG_DIR/ffmpeg"
  cat > "$FFMPEG_DIR/index.js" << 'EOF'
const path = require("path");
module.exports = path.join(__dirname, "ffmpeg");
EOF
  cat > "$FFMPEG_DIR/package.json" << 'EOF'
{"name":"ffmpeg-static","version":"5.2.0","main":"index.js"}
EOF
fi

echo "[5/5] Creating launcher command & desktop shortcuts..."
mkdir -p "$BIN_DIR" "$APPS_DIR"

cat > "$BIN_DIR/nocturnal-player" << EOF
#!/usr/bin/env bash
exec "$INSTALL_DIR/nocturnal-player" --no-sandbox "\$@"
EOF
chmod +x "$BIN_DIR/nocturnal-player"

# Create Uninstall script inside $INSTALL_DIR
cat > "$INSTALL_DIR/uninstall.sh" << EOF
#!/usr/bin/env bash
rm -f "$BIN_DIR/nocturnal-player"
rm -f "$APPS_DIR/nocturnal-player.desktop"
rm -f "$HOME/Desktop/Nocturnal player.desktop"
rm -rf "$INSTALL_DIR"
echo "Nocturnal player has been uninstalled."
EOF
chmod +x "$INSTALL_DIR/uninstall.sh"

ICON_PATH="$RESOURCES_APP/assets/180px-soundtrack_(nocturnal_style).png"
DESKTOP_FILE="$APPS_DIR/nocturnal-player.desktop"
cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Type=Application
Name=Nocturnal player
Comment=Nocturnal player — standalone desktop music player
Exec="$BIN_DIR/nocturnal-player"
Path=$INSTALL_DIR
Icon=$ICON_PATH
Terminal=false
Categories=AudioVideo;Audio;Player;
EOF
chmod +x "$DESKTOP_FILE"

if [ -d "$HOME/Desktop" ]; then
  cp "$DESKTOP_FILE" "$HOME/Desktop/Nocturnal player.desktop" 2>/dev/null || true
  chmod +x "$HOME/Desktop/Nocturnal player.desktop" 2>/dev/null || true
fi

echo ""
echo "============================================================"
echo "  SUCCESS! Installed to: $INSTALL_DIR"
echo "  Command: ~/.local/bin/nocturnal-player"
echo "  Launching Nocturnal player..."
echo "============================================================"
nohup "$BIN_DIR/nocturnal-player" >/dev/null 2>&1 &
exit 0

============================================================
  [::] NOCTURNAL PLAYER — LINUX INSTALLER INSTRUCTIONS
============================================================

HOW TO INSTALL ON LINUX (Arch / Hyprland / Ubuntu / Fedora / Debian — x64 & ARM64):

1. Extract "Nocturnal-Player-Linux-Installer.zip".
2. Open a terminal in the extracted folder and run:

   ./install-nocturnal-player.sh

   (Or double-click "install-nocturnal-player.sh" and choose "Run in Terminal".)

3. The installer will automatically:
   - Detect whether your Linux system is x86_64 or ARM64
   - Install Nocturnal player into ~/.local/opt/nocturnal-player
   - Create ~/.local/bin/nocturnal-player and an application launcher entry
   - Launch Nocturnal player automatically!

To uninstall anytime, run:
   ~/.local/opt/nocturnal-player/uninstall.sh
